# Simple tinymce + webpack example

This shows a simple example of tinymce being used with webpack.

Usage:

1. Clone repo
2. Run `npm install` to install packages
3. Run `npm run start` to start dev server